<div class="flex-flex-col w-full border-x border-b drop-shadow-sm shadow-sm">
    <div class="flex flex-row justify-between items-center px-4 pt-2 pb-1 bg-[#F5F5F5]">
        <p class="font-sans font-medium text-base text-left"><?php echo e($document->type); ?> No.<?php echo e($document->number); ?>, s. <?php echo e(date('Y', strtotime($document->date))); ?></p>
        
        <?php if($document->area == 'Financial Administration and Sustainability'): ?>
            <img src="<?php echo e(asset('/images/Financial_Administration_and_Sustainability.svg')); ?>" alt="" class="h-8 w-8">
        <?php elseif($document->area == 'Disaster Preparedness'): ?>
            <img src="<?php echo e(asset('/images/Disaster_Preparedness.svg')); ?>" alt="" class="h-8 w-8">
        <?php elseif($document->area == 'Safety, Peace and Order'): ?>
            <img src="<?php echo e(asset('/images/Safety_Peace_and_Order.svg')); ?>" alt="" class="h-8 w-8">
        <?php elseif($document->area == 'Social Protection and Sensitivity'): ?>
            <img src="<?php echo e(asset('/images/Social_Protection_and_Sensitivity.svg')); ?>" alt="" class="h-8 w-8">
        <?php elseif($document->area == 'Business-Friendliness and Competitiveness'): ?>
            <img src="<?php echo e(asset('/images/Business_Friendliness_and_Competitiveness.svg')); ?>" alt="" class="h-8 w-8">
        <?php elseif($document->area == 'Environmental Management'): ?>
            <img src="<?php echo e(asset('/images/Environmental_Management.svg')); ?>" alt="" class="h-8 w-8">
        <?php endif; ?>

    </div>
    <p class="text-base font-normal uppercase text-black/60 px-4 pt-2 bg-white">
        <?php echo e($document->title); ?>

    </p>
    <div class="flex flex-col px-4 pb-2 bg-white">
        <p class="text-base font-bold text-black/60 pt-2">
            Date of Enactment | <?php echo e(date('M d, Y', strtotime($document->date))); ?>

        </p>
        <div class="flex flex-col justify-start items-end md:flex-row md:justify-between">
            <p class="text-base font-bold text-black/60">
                Author/s | 
                    <?php
                        $authors = [];
                    ?>
                    <?php $__currentLoopData = $document->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            array_push($authors, $author->name);
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(join(", ", $authors)); ?>

                    <?php
                        if(count($authors) <= 0){
                            echo "No author";
                        }
                    ?>
            </p>
            <div class="flex flex-row justify-end items-end space-x-4">
                <a href=<?php echo e('/download'.'/'.substr($document->file, 10)); ?> target="_blank" rel="noopener noreferrer" class="rounded-sm hover:bg-[#F5F5F5] hover:scale-150">
                    <img src="<?php echo e(asset('/images/download.svg')); ?>" alt="Download" title="Download">
                </a>
                <button type="button" data-file="<?php echo e($document->file); ?>" class="view rounded-sm hover:bg-[#F5F5F5] hover:scale-150">
                    <img src="<?php echo e(asset('/images/view.svg')); ?>" alt="Open" title="Open" class="-translate-y-1">
                </button>
                <button type="button" data-id="<?php echo e($document->id); ?>" class="restore rounded-sm hover:bg-[#F5F5F5] hover:scale-150">
                    <img src="<?php echo e(asset('/images/restore.svg')); ?>" alt="Restore" title="Restore">
                </button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\BLTS\resources\views/components/deleted-card.blade.php ENDPATH**/ ?>