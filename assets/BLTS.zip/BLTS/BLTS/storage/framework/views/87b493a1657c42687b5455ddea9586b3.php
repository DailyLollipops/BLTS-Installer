<div id="viewer" class="hidden fixed right-0 bottom-0 h-full w-full flex flex-col items-center border drop-shadow-md shadow-lg modal-container bg-white rounded z-10 animated faster pt-12">
    <iframe id="viewer-frame" src ="" class="h-full w-full"></iframe>
</div>

<script src="<?php echo e(asset('/js/document_viewer.js')); ?>"></script>
<?php /**PATH C:\laragon\www\BLTS\resources\views/components/modal/document-viewer.blade.php ENDPATH**/ ?>