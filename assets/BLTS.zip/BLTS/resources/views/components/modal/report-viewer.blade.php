<div id="report-viewer" class="hidden fixed right-0 bottom-0 h-full w-full flex flex-col items-center border drop-shadow-md shadow-lg modal-container bg-white rounded z-10 animated faster pt-12">
    <iframe id="report-viewer-frame" src ="" class="h-full w-full"></iframe>
</div>

<script src="{{ asset('/js/report_viewer.js') }}"></script>